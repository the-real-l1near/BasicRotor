package com.l1near.basicrotor.assembly.runtime;

/*
---------------------------
Imports
---------------------------
*/

import com.l1near.basicrotor.assembly.LinkedAssembly;
import com.l1near.basicrotor.assembly.LinkedBlockData;
import com.l1near.basicrotor.movement.MovementData;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

import java.util.Map;

public class AssemblyRuntime {
    /*
    ---------------------------
    Fields
    ---------------------------
    */

    private boolean virtualized;


    /*
    ---------------------------
    Constructors
    ---------------------------
    */

    public AssemblyRuntime() {
        this.virtualized = false;
    }

    /*
    ---------------------------
    Methods
    ---------------------------
    */

    //Update
    public boolean update(
            Level level,
            LinkedAssembly assembly,
            MovementData movementData
    ) {
        boolean wasVirtualized = virtualized;

        switch (movementData.getState()) {

            case STOPPED -> updateStopped();

            case STARTING -> updateStarting();

            case RUNNING -> updateRunning();

            case BRAKING -> updateBraking();

            case RETURNING -> updateReturning();
        }

        boolean startedVirtualizing =
                !wasVirtualized
                        && virtualized;

        if (!wasVirtualized && virtualized) {

            refreshBlockStates(
                    level,
                    assembly
            );

            virtualizeBlocks(
                    level,
                    assembly
            );
        }

        if (wasVirtualized && !virtualized) {
            restoreBlocks(
                    level,
                    assembly
            );
        }
        return startedVirtualizing;
    }



    private void updateStopped() {
        virtualized = false;
    }

    private void updateStarting() {
        virtualized = true;
    }

    private void updateRunning() {
        virtualized = true;
    }

    private void updateBraking() {
        virtualized = true;
    }

    private void updateReturning() {
        virtualized = true;
    }

    //Virtualize
    private void virtualizeBlocks(
            Level level,
            LinkedAssembly assembly
    ) {

        BlockPos originPos =
                assembly.getOriginPos();

        for (Map.Entry<BlockPos, LinkedBlockData> entry
                : assembly.getEntries()) {

            BlockPos relativePos =
                    entry.getKey();

            BlockPos worldPos =
                    originPos.offset(relativePos);

            level.setBlock(
                    worldPos,
                    Blocks.AIR.defaultBlockState(),
                    3
            );
        }
    }

    //Refresh Block States
    private void refreshBlockStates(
            Level level,
            LinkedAssembly assembly
    ) {

        BlockPos originPos =
                assembly.getOriginPos();

        for (Map.Entry<BlockPos, LinkedBlockData> entry
                : assembly.getEntries()) {

            BlockPos worldPos =
                    originPos.offset(
                            entry.getKey()
                    );

            entry.getValue()
                    .setBlockState(
                            level.getBlockState(
                                    worldPos
                            )
                    );
        }
    }

    //Restore
    private void restoreBlocks(
            Level level,
            LinkedAssembly assembly
    ) {

        BlockPos originPos =
                assembly.getOriginPos();

        for (Map.Entry<BlockPos, LinkedBlockData> entry
                : assembly.getEntries()) {

            BlockPos relativePos =
                    entry.getKey();

            LinkedBlockData blockData =
                    entry.getValue();

            BlockPos worldPos =
                    originPos.offset(relativePos);

            level.setBlock(
                    worldPos,
                    blockData.getBlockState(),
                    3
            );
        }
    }

    //Getters
    public boolean isVirtualized() {
        return virtualized;
    }

}