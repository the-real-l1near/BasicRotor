package com.l1near.basicrotor.movement;

/*
---------------------------
Imports
---------------------------
*/

import net.minecraft.util.Mth;

public class MovementRuntime {

    /*
    ---------------------------
    Fields
    ---------------------------
    */

    private final MovementData movementData;

    private void updateRunning(MovementInput input) {

        movementData.setLastRotation(
                movementData.getRotation()
        );

        movementData.setSpeed(
                movementData.getSpeed()
                        + movementData.getAcceleration()
        );

        movementData.setSpeed(
                Mth.clamp(
                        movementData.getSpeed(),
                        -movementData.getMaxSpeed(),
                        movementData.getMaxSpeed()
                )
        );

        movementData.setSpeed(
                movementData.getSpeed()
                        * movementData.getFriction()
        );

        movementData.setRotation(
                movementData.getRotation()
                        + movementData.getSpeed()
        );
    }

    private void updateBraking(MovementInput input) {

    }

    private void updateReturning(MovementInput input) {

    }

    private void updateStopped(MovementInput input) {

    }

    /*
    ---------------------------
    Constructors
    ---------------------------
    */

    public MovementRuntime(MovementData movementData) {
        this.movementData = movementData;
    }

    /*
    ---------------------------
    Methods
    ---------------------------
    */

    //Tick
    public void tick(MovementInput input) {
        if (input.isPowered()) {

            movementData.setState(
                    MovementState.RUNNING
            );

        } else {

            movementData.setState(
                    MovementState.BRAKING
            );
        }
        System.out.println(
                "Movement state: "
                        + movementData.getState()
        );
        switch (movementData.getState()) {

            case RUNNING ->
                    updateRunning(input);

            case BRAKING ->
                    updateBraking(input);

            case RETURNING ->
                    updateReturning(input);

            case STOPPED ->
                    updateStopped(input);
        }
    }

}