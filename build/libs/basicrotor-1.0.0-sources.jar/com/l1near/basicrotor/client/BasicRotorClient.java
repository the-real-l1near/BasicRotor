package com.l1near.basicrotor.client;

/*
---------------------------
Imports
---------------------------
*/

import com.l1near.basicrotor.client.movement.ClientRotorMovementData;
import com.l1near.basicrotor.client.render.RotorBlockEntityRenderer;
import com.l1near.basicrotor.registry.ModBlockEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import com.l1near.basicrotor.client.assembly.ClientAssemblyManager;
import com.l1near.basicrotor.client.assembly.VirtualAssemblyData;
import com.l1near.basicrotor.network.payload.AssemblySnapshotPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.world.level.block.Block;
import com.l1near.basicrotor.assembly.LinkedBlockData;
import com.l1near.basicrotor.network.payload.RotorMovementPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import com.l1near.basicrotor.network.payload.AssemblyRequestPayload;
import com.l1near.basicrotor.network.payload.AssemblyRemovePayload;
import com.l1near.basicrotor.client.movement.ClientRotorMovementManager;
import com.l1near.basicrotor.network.payload.RotorRemovePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public class BasicRotorClient implements ClientModInitializer {

    /*
    ---------------------------
    Fields
    ---------------------------
    */

    private static final ClientAssemblyManager ASSEMBLY_MANAGER =
            new ClientAssemblyManager();

    private static final ClientRotorMovementManager ROTOR_MOVEMENT_MANAGER =
            new ClientRotorMovementManager();

    /*
    ---------------------------
    Methods
    ---------------------------
    */

    //Getters
    public static ClientAssemblyManager getAssemblyManager() {
        return ASSEMBLY_MANAGER;
    }

    //Overides
    @Override
    public void onInitializeClient() {

        BlockEntityRenderers.register(
                ModBlockEntities.ROTOR,
                RotorBlockEntityRenderer::new
        );

        ClientPlayNetworking.registerGlobalReceiver(
                AssemblySnapshotPayload.TYPE,
                (payload, context) -> {

                    if (context.client().level == null) {
                        return;
                    }

                    context.client().execute(() -> {
                        VirtualAssemblyData assembly =
                                new VirtualAssemblyData(
                                        payload.rotorPos()
                                );

                        for (AssemblySnapshotPayload.BlockEntry entry
                                : payload.blocks()) {

                            assembly.addBlock(
                                    entry.relativePos(),
                                    new LinkedBlockData(
                                            Block.stateById(
                                                    entry.blockStateId()
                                            )
                                    )
                            );
                        }

                        ASSEMBLY_MANAGER.register(
                                context.client().level.dimension(),
                                payload.rotorPos(),
                                assembly
                        );

                        ASSEMBLY_MANAGER.clearPending(
                                context.client().level.dimension(),
                                payload.rotorPos()
                        );
                    });
                }
        );

        ClientPlayNetworking.registerGlobalReceiver(
                RotorMovementPayload.TYPE,
                (payload, context) -> {

                    context.client().execute(() -> {

                        if (context.client().level == null) {
                            return;
                        }

                        ClientRotorMovementData rotorMovement =
                                ROTOR_MOVEMENT_MANAGER.getOrCreate(
                                        context.client().level.dimension(),
                                        payload.rotorPos()
                                );

                        rotorMovement.setRotation(
                                payload.rotation()
                        );

                        rotorMovement.setRotationStep(
                                payload.rotationStep()
                        );

                        rotorMovement.setMoving(
                                payload.moving()
                        );

                        VirtualAssemblyData assembly =
                                ASSEMBLY_MANAGER.get(
                                        context.client().level.dimension(),
                                        payload.rotorPos()
                                );

                        if (assembly == null) {

                            if (ASSEMBLY_MANAGER.markPending(
                                    context.client().level.dimension(),
                                    payload.rotorPos()
                            )) {

                                ClientPlayNetworking.send(
                                        new AssemblyRequestPayload(
                                                payload.rotorPos()
                                        )
                                );
                            }

                            return;
                        }

                        assembly.setRotation(
                                payload.rotation()
                        );

                        assembly.setRotationStep(
                                payload.rotationStep()
                        );

                        assembly.setVirtualized(
                                payload.virtualized()
                        );
                    });
                }
        );

        ClientPlayNetworking.registerGlobalReceiver(
                AssemblyRemovePayload.TYPE,
                (payload, context) -> {

                    context.client().execute(() -> {

                        if (context.client().level == null) {
                            return;
                        }

                        ASSEMBLY_MANAGER.remove(
                                context.client().level.dimension(),
                                payload.rotorPos()
                        );

                        ASSEMBLY_MANAGER.clearPending(
                                context.client().level.dimension(),
                                payload.rotorPos()
                        );
                    });
                }
        );

        ClientPlayNetworking.registerGlobalReceiver(
                RotorRemovePayload.TYPE,
                (payload, context) -> {

                    context.client().execute(() -> {

                        if (context.client().level == null) {
                            return;
                        }

                        ROTOR_MOVEMENT_MANAGER.remove(
                                context.client().level.dimension(),
                                payload.rotorPos()
                        );
                    });
                }
        );

        ClientPlayConnectionEvents.DISCONNECT.register(
                (handler, client) -> {

                    ASSEMBLY_MANAGER.clear();

                    ROTOR_MOVEMENT_MANAGER.clear();
                }
        );

        ClientTickEvents.END_CLIENT_TICK.register(
                client -> {

                    if (client.level == null) {
                        return;
                    }

                    var dimension =
                            client.level.dimension();

                    for (var entry
                            : ASSEMBLY_MANAGER.getEntries()) {

                        if (!entry.getKey()
                                .dimension()
                                .equals(dimension)) {
                            continue;
                        }

                        entry.getValue()
                                .tickRenderRotation();
                    }

                    for (var entry
                            : ROTOR_MOVEMENT_MANAGER.getEntries()) {

                        if (!entry.getKey()
                                .dimension()
                                .equals(dimension)) {
                            continue;
                        }

                        entry.getValue()
                                .tickRenderRotation();
                    }
                }
        );

    }
    //Geters
    public static ClientRotorMovementManager getRotorMovementManager() {
        return ROTOR_MOVEMENT_MANAGER;
    }
}